package enums;

public interface Type {

    SuperType getType();
    String getTypeID();
}
